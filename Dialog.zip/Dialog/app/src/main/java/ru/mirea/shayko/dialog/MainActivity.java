package ru.mirea.shayko.dialog;

import androidx.appcompat.app.AppCompatActivity;

import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private TextView time;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        time = (TextView) findViewById(R.id.time);
    }

    // Обычное диалоговое окно:
    public void onClickShowDialog(View view) {
        MyDialogFragment dialogFragment = new MyDialogFragment();
        dialogFragment.show(getSupportFragmentManager(), view.toString());
    }

    public void onOkClicked() {
        Toast.makeText(getApplicationContext(), "Вы выбрали кнопку \"Иду дальше\"!", Toast.LENGTH_LONG)
                .show();
    }
    public void onCancelClicked() {
        Toast.makeText(getApplicationContext(), "Вы выбрали кнопку \"Нет\"!", Toast.LENGTH_LONG)
                .show();
    }
    public void onNeutralClicked() {
        Toast.makeText(getApplicationContext(), "Вы выбрали кнопку \"На паузе\"!", Toast.LENGTH_LONG)
                .show();
    }

    // Диалоговое окно времени:
    public void onClickShowTimeDialog(View view) {
        MyTimeDialogFragment timeDialog = new MyTimeDialogFragment(getApplicationContext(),timeListener,0,0,true);
        timeDialog.setButton(-3, "Покинуть окно", setTimeButtonClick);
        timeDialog.setTitle("Привет, друг!)");
        timeDialog.setMessage("Выбери твоё любимоё время");
        timeDialog.show();
    }

    DialogInterface.OnClickListener setTimeButtonClick = new DialogInterface.OnClickListener() {
        @Override
        public void onClick(DialogInterface dialog, int which) {
            Toast.makeText(getApplicationContext(), "Ты покинул область редактирования времени", Toast.LENGTH_LONG).show();
        }
    };

    OnTimeSetListener timeListener = new OnTimeSetListener() {
        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            time.setText("Time is " + hourOfDay + " hours " + minute + " minutes");
        }
    };

    // Другие диалоговые окна (даты и прогресса):
    public void onClickShowDateDialog(View view) {
    }

    public void onClickShowProgressDialog(View view) {
    }
}