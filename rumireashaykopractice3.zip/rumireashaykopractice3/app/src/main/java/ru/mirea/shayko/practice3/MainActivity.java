package ru.mirea.shayko.practice3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void runActivity2(View view) {
        long dateInMillis = System.currentTimeMillis();
        String format = "yyyy-MM-dd HH:mm:ss";
        final SimpleDateFormat sdf = new SimpleDateFormat(format);
        String dateString = sdf.format(new Date(dateInMillis));

        Intent timeViewIntent = new Intent(Intent.ACTION_VIEW);
        timeViewIntent.addCategory(Intent.CATEGORY_DEFAULT);
        timeViewIntent.putExtra("time", dateString);
        if (timeViewIntent.resolveActivity(getPackageManager()) != null) {
            startActivity(timeViewIntent);
        } else {
            Toast.makeText(MainActivity.this, "Не удалось отобразить текущее время :(", Toast.LENGTH_LONG);
        }
    }
}