package ru.mirea.shayko.practice1;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private ImageView image;
    private ImageView image2;
    private TextView text;
    View.OnTouchListener onTouch;
    View.OnLongClickListener onClick;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        image = findViewById(R.id.imageView);
        image2 = findViewById(R.id.imageView2);
        text = findViewById(R.id.textView);

        onTouch = new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                    if (v == image)
                    {
                        image.setVisibility(View.INVISIBLE);
                        image2.setVisibility(View.VISIBLE);
                    } else
                    {
                        image2.setVisibility(View.INVISIBLE);
                        image.setVisibility(View.VISIBLE);
                    }

                    return true;
            }
        };

        onClick = new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                setContentView(R.layout.linear_layout);
                return true;
            }
        };

        image.setOnTouchListener(onTouch);
        image2.setOnTouchListener(onTouch);
        text.setOnLongClickListener(onClick);
    }

    public void onLineButtonClick(View view)
    {
        setContentView(R.layout.table_layout);
    }

    public void onTableButtonClick(View view)
    {
        image2.setVisibility(View.INVISIBLE);
        image.setVisibility(View.VISIBLE);
        setContentView(R.layout.activity_main);
    }

    public void onTableButtonClickPurple(View view)
    {
        setContentView(R.layout.linear_layout);
    }
}